export const SAVE_TIMELINE_ENTRY_SUCCESS = 'SAVE_TIMELINE_ENTRY_SUCCESS';
export const SAVE_TIMELINE_ENTRY_FAILURE = 'SAVE_TIMELINE_ENTRY_FAILURE';

export const saveTimelineEntrySuccess = (formData) => ({
  type: SAVE_TIMELINE_ENTRY_SUCCESS,
  payload: formData,
});

export const saveTimelineEntryFailure = (error) => ({
  type: SAVE_TIMELINE_ENTRY_FAILURE,
  payload: error,
});
