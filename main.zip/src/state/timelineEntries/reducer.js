const initialState = {
  entries: [],
  loading: false,
  error: null,
};

const timelineEntriesReducer = (state = initialState, action) => {
  switch (action.type) {
    case 'SAVE_TIMELINE_ENTRY_SUCCESS':
      return {
        ...state,
        entries: [ ...state.entries, action.payload ],
        loading: false,
      };
    case 'SAVE_TIMELINE_ENTRY_FAILURE':
      return {
        ...state,
        error: action.payload,
        loading: false,
      };
    default:
      return state;
  }
};

export default timelineEntriesReducer;
