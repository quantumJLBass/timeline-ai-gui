import { createEntry as createTimelineEntryAPI } from '../../db/services/TimelineEntryService';
import { saveTimelineEntrySuccess, saveTimelineEntryFailure } from './actions';

export const saveTimelineEntry = (formData) => async (dispatch) => {
  try {
    await createTimelineEntryAPI(formData);
    dispatch(saveTimelineEntrySuccess(formData));
  } catch (error) {
    console.error("Failed to save timeline entry:", error);
    dispatch(saveTimelineEntryFailure(error));
  }
};
