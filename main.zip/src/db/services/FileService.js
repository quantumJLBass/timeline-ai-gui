const handleFileUpload = async (file) => {
  // FALSE INPUT_NOT_REQUIRED {you are doing implementation_logic_for_file_uploading}
  // THERE IS NOT TO BE ANY example ANYTHING
  return '/path/to/' + file.name;
};

module.exports = {
  handleFileUpload,
};
