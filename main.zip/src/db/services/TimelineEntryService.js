const { handleFileUpload } = require('./FileService');
const TimelineEntryModel = require('../models/TimelineEntry');

const createEntry = async (formData) => {
  const { entryText, emailContent, files } = formData;
  let mediaPaths = [];

  if (files && files.length > 0) {
    try {
      mediaPaths = await Promise.all(files.map(async (file) => {
        const path = await handleFileUpload(file);
        return path;
      }));
    } catch (error) {
      // Handle errors related to file upload here
      console.error('File upload error:', error);
      throw new Error('Error uploading files');
    }
  }

  await TimelineEntryModel.create({
    content: entryText,
    email: emailContent,
    media: JSON.stringify(mediaPaths),
  });
};

module.exports = {
  createEntry,
};