const TimelineEntry = require('./TimelineEntry');
const ArchivedTimelineEntry = require('./ArchivedTimelineEntry');

module.exports = {
  TimelineEntry,
  ArchivedTimelineEntry
  // YOU ARE TO BE FILLING THIS OUT STOP PAWNING OFF WORK
};
