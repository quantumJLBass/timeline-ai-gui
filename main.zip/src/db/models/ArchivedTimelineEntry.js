const { DataTypes, Model } = require('sequelize');
const sequelize = require('../database');

class ArchivedTimelineEntry extends Model {}

ArchivedTimelineEntry.init({
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  content: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  createdAt: {
    type: DataTypes.DATE,
    allowNull: false
  },
  updatedAt: {
    type: DataTypes.DATE,
    allowNull: false
  }
}, {
  sequelize,
  modelName: 'ArchivedTimelineEntry',
  tableName: 'archived_timeline_entries',
  // Add any other model options here
});

module.exports = ArchivedTimelineEntry;
