const { DataTypes, Model } = require('sequelize');
const sequelize = require('../database');
const CryptoJS = require('crypto-js');
const encryptionKey = process.env.ENCRYPTION_KEY;

class TimelineEntry extends Model {}

TimelineEntry.init({
  // ...existing columns
  content: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
  email: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  media: {
    type: DataTypes.TEXT, // JSON string of media file paths
    allowNull: true,
  },
  // ...rest of the model definition
}, {
  sequelize,
  modelName: 'TimelineEntry',
  tableName: 'timeline_entries',
});

TimelineEntry.addHook('afterFind', (result) => {
  const decryptContent = (entry) => {
    if (!entry) return;
    entry.content = CryptoJS.AES.decrypt(entry.content, encryptionKey).toString(CryptoJS.enc.Utf8);
  };

  if (Array.isArray(result)) {
    result.forEach(entry => decryptContent(entry));
  } else {
    decryptContent(result);
  }
});

module.exports = TimelineEntry;
