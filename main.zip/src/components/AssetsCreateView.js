import React from 'react';

const AssetsCreateView = () => {
  return (
    <div>
      Assets Create View goes here.
    </div>
  );
};

export default AssetsCreateView;
