import React from 'react';
import { Link } from 'react-router-dom';
console.log("MainMenu.js");
const MainMenu = () => {
  return (
    <nav>
      <ul>
        <li><Link to="/settings">Settings</Link></li>
        <li><Link to="/timeline">Timeline</Link></li>
        <li><Link to="/entries/list">Entry List</Link></li>
        <li><Link to="/entries/create">Create Entry</Link></li>
        <li><Link to="/entries/edit">Edit Entry</Link></li>
        <li><Link to="/entries/delete">Delete Entry</Link></li>
        <li><Link to="/assets/list">Assets List</Link></li>
        <li><Link to="/assets/create">Create Asset</Link></li>
        <li><Link to="/assets/edit">Edit Asset</Link></li>
        <li><Link to="/assets/delete">Delete Asset</Link></li>
      </ul>
    </nav>
  );
};

export default MainMenu;
