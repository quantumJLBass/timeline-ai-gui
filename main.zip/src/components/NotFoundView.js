import React from 'react';

const NotFoundView = () => {
  return (
    <div>
      <h2>404</h2>
      {/* Settings content will go here */}
    </div>
  );
};

export default NotFoundView;
