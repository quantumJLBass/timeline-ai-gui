import React from 'react';

const SettingsView = () => {
  return (
    <div>
      <h2>Settings</h2>
      {/* Settings content will go here */}
    </div>
  );
};

export default SettingsView;
