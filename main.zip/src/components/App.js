import React from 'react';
import MainMenu from './MainMenu/MainMenu';
import { HashRouter as Router, Route, Routes } from 'react-router-dom';
import SettingsView from './SettingsView';
import TimelineView from './TimelineView';
import EntryListView from './EntryListView';
import EntryCreateView from './EntryCreateView';
import EntryEditView from './EntryEditView';
import EntryDeleteView from './EntryDeleteView';
import AssetsListView from './AssetsListView';
import AssetsCreateView from './AssetsCreateView';
import AssetsEditView from './AssetsEditView';
import AssetsDeleteView from './AssetsDeleteView';
import NotFoundView from './NotFoundView';
import ErrorBoundary from './ErrorBoundary';
import HomeView from './HomeView';
console.log("App.js");
const App = () => {
  return (
    <Router>
      <MainMenu />
      <ErrorBoundary>
        <Routes>
          <Route path="/" element={<HomeView />} />
          <Route path="/settings" element={<SettingsView />} />
          <Route path="/timeline" element={<TimelineView />} />
          <Route path="/entries/list" element={<EntryListView />} />
          <Route path="/entries/create" element={<EntryCreateView />} />
          <Route path="/entries/edit/:id" element={<EntryEditView />} />
          <Route path="/entries/delete/:id" element={<EntryDeleteView />} />
          <Route path="/assets/list" element={<AssetsListView />} />
          <Route path="/assets/create" element={<AssetsCreateView />} />
          <Route path="/assets/edit/:id" element={<AssetsEditView />} />
          <Route path="/assets/delete/:id" element={<AssetsDeleteView />} />
          <Route path="*" element={<NotFoundView />} />
        </Routes>
      </ErrorBoundary>
    </Router>
  );
};

export default App;
