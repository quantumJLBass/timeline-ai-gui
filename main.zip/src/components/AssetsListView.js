import React from 'react';

const AssetsListView = () => {
  return (
    <div>
      Assets List View goes here.
    </div>
  );
};

export default AssetsListView;
