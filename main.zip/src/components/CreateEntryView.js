import React from 'react';
import TimelineEntryForm from './TimelineEntryForm/TimelineEntryForm';

const CreateEntryView = () => {
  return (
    <div>
      <h2>Create Entry</h2>
      <TimelineEntryForm />
    </div>
  );
};

export default CreateEntryView;
