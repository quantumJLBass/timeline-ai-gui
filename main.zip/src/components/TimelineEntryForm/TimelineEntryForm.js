import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { saveTimelineEntry } from '../../state/timelineEntries/thunks';

const TimelineEntryForm = () => {
  const [entryText, setEntryText] = useState('');
  const [mediaFiles, setMediaFiles] = useState([]);
  const [emailContent, setEmailContent] = useState('');
  const dispatch = useDispatch();

  const handleTextChange = (event) => {
    setEntryText(event.target.value);
  };

  const handleMediaChange = (event) => {
    setMediaFiles([...mediaFiles, ...event.target.files]);
  };

  const handleEmailChange = (event) => {
    setEmailContent(event.target.value);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const formData = new FormData();
    formData.append('entryText', entryText);
    formData.append('emailContent', emailContent);
    mediaFiles.forEach((mediaFile, index) =>
      formData.append(`mediaFile${index}`, mediaFile)
    );
    dispatch(saveTimelineEntry(formData));
    setEntryText('');
    setEmailContent('');
    setMediaFiles([]);
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label htmlFor="entryText">Entry Text:</label>
        <textarea id="entryText" value={entryText} onChange={handleTextChange} />
      </div>
      <div>
        <label htmlFor="mediaFiles">Media Files:</label>
        <input id="mediaFiles" type="file" multiple onChange={handleMediaChange} />
      </div>
      <div>
        <label htmlFor="emailContent">Email Content:</label>
        <textarea id="emailContent" value={emailContent} onChange={handleEmailChange} />
      </div>
      <button type="submit">Create Timeline Entry</button>
    </form>
  );
};

export default TimelineEntryForm;
