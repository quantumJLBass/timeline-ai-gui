import React from 'react';

const EntryListView = () => {
  return (
    <div>
      Entry List View goes here.
    </div>
  );
};

export default EntryListView;
