import React from 'react';

const AssetsDeleteView = () => {
  return (
    <div>
      Assets Delete View goes here.
    </div>
  );
};

export default AssetsDeleteView;
