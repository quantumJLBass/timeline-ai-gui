import React from 'react';

const EntryCrudView = () => {
  return <div>Entry CRUD Operations will be handled here.</div>;
};

export default EntryCrudView;
