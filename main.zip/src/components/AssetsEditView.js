import React from 'react';

const AssetsEditView = () => {
  return (
    <div>
      Assets Edit View goes here.
    </div>
  );
};

export default AssetsEditView;
