import React from 'react';

const EntryCreateView = () => {
  return (
    <div>
      <h2>Entry Create View</h2>
      <p>Entry Create View goes here.</p>
      {/* FALSE INPUT_NOT_REQUIRED {YOU ARE Adding the form and related logic for creating a new entry.  DON'T ASL FOR THE HUMAN TO DO YOUR WORK AGAIN */}
    </div>
  );
};

export default EntryCreateView;
