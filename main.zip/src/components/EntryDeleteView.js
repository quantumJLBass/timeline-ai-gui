import React from 'react';

const EntryDeleteView = () => {
  return (
    <div>
      Entry Delete View goes here.
    </div>
  );
};

export default EntryDeleteView;
