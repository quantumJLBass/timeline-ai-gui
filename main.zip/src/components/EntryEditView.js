import React from 'react';

const EntryEditView = () => {
  return (
    <div>
      Entry Edit View goes here.
    </div>
  );
};

export default EntryEditView;
